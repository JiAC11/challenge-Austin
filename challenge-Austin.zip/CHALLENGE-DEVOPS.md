# DevOps Challenge

## Working on the challenge

- Please provide a summary of approach and proper documentation.
- It is strongly recommended to use git or other version control on your code and submit the commit history as part of submission.

## Instructions

Feel free to use a container or virtualization solution of your choice, but keep in mind the tester must be able to recreate the environment purely from your instructions. The instructions should include any dependencies. Keep in mind simplicity is a key factor.

- Automate the creation of a db server and a web app server and configure them.
- (extra) Set up HTTPS for web app using self-signed certificate and redirect HTTP to HTTPS site.
- (extra) Use SSL connection on MySQL using self-signed certificate.
- (extra) Set up MySQL replication.

## Submitting your git repository

- NEVER upload the code to public.
- Submit the zip file of your source code repository.

```sh
cd /tmp
git clone /path/to/working-copy challenge-Austin
zip -r -9 challenge-.zip challenge-Austin
```
