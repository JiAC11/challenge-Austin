PART1: Automate Creation of DB server and Web app server, configure them
        
First I installed the appropriate Gem's required for the app.rb file which included mysql2, dotenv, puma, thin, and sinatra

Second I set up the database with the script:
   "mysql -u root -p schema_database < schema.sql"

Third I created the .env specified by the require dotenv:

    MYSQL_HOST=localhost
    MYSQL_USERNAME=root
    MYSQL_PASSWORD=*****
    MYSQL_PORT=3306
    MYSQL_DATABASE=data1
    MYSQL_SSL_KEY=/path/to/client-key.pem
    MYSQL_SSL_CERT=/path/to/client-cert.pem
    MYSQL_SSL_CA=/path/to/ca-cert.pem
    MYSQL_SSL_CA_PATH=/path/to/cacerts
    MYSQL_SSL_CIPHER=DHE-RSA-AES256-SHA


